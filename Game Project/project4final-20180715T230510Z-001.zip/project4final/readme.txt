to make test scene, type: make
into the command line

To make creative project, type: make creative
into the command line
